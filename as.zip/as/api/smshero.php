<?php
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    sendError('Unauthorized', 401);
}

// Load config to get API key
$config = loadJson('config.json');
if (!$config || empty($config['api']['key'])) {
    sendError('API key not configured. Please contact admin.', 500);
}

$apiKey = $config['api']['key'];
$apiUrl = $config['api']['url'] ?? 'https://hero-sms.com/stubs/handler_api.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';

function callSmsHero($params) {
    global $apiUrl, $apiKey;
    
    $url = $apiUrl . '?' . http_build_query(array_merge($params, ['api_key' => $apiKey]));
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($error) {
        return ['error' => 'Connection error: ' . $error];
    }
    
    if ($httpCode !== 200) {
        return ['error' => 'HTTP error: ' . $httpCode];
    }
    
    // Parse SMS Hero response
    $response = trim($response);
    
    // Check for errors
    if (strpos($response, 'ERROR') === 0 || strpos($response, 'BAD') === 0) {
        return ['error' => $response];
    }
    
    // Parse ACCESS_NUMBER response: ACCESS_NUMBER:activation_id:number
    if (strpos($response, 'ACCESS_NUMBER:') === 0) {
        $parts = explode(':', $response);
        if (count($parts) >= 3) {
            return [
                'success' => true,
                'activationId' => $parts[1],
                'number' => $parts[2]
            ];
        }
    }
    
    // Parse ACCESS_BALANCE response: ACCESS_BALANCE:amount
    if (strpos($response, 'ACCESS_BALANCE:') === 0) {
        $parts = explode(':', $response);
        if (count($parts) >= 2) {
            return [
                'success' => true,
                'balance' => $parts[1]
            ];
        }
    }
    
    // Parse STATUS responses
    if (strpos($response, 'STATUS_OK:') === 0) {
        $parts = explode(':', $response);
        return [
            'success' => true,
            'status' => 'OK',
            'code' => $parts[1] ?? ''
        ];
    }
    
    if (strpos($response, 'STATUS_WAIT_CODE') === 0) {
        return [
            'success' => true,
            'status' => 'WAIT_CODE'
        ];
    }
    
    if (strpos($response, 'STATUS_CANCEL') === 0) {
        return [
            'success' => true,
            'status' => 'CANCEL'
        ];
    }
    
    if (strpos($response, 'STATUS_FINISH') === 0) {
        return [
            'success' => true,
            'status' => 'FINISH'
        ];
    }
    
    // Return raw response for debugging
    return ['success' => true, 'raw' => $response];
}

// Process pending cancels (135 second delay)
function processPendingCancels() {
    $pending = loadJson('pending_cancels.json');
    if (!$pending || empty($pending['pending'])) {
        return;
    }
    
    $now = time();
    $remaining = [];
    
    foreach ($pending['pending'] as $cancel) {
        $executeTime = strtotime($cancel['executeAt']);
        
        if ($now >= $executeTime) {
            // Time to execute the cancel
            callSmsHero([
                'action' => 'setStatus',
                'status' => '8',
                'id' => $cancel['activationId']
            ]);
            
            // Log the cancel
            logAction($cancel['userId'], 'system', 'AUTO_CANCEL', 'Cancelled activation: ' . $cancel['activationId'] . ' after 135s delay');
        } else {
            $remaining[] = $cancel;
        }
    }
    
    $pending['pending'] = $remaining;
    saveJson('pending_cancels.json', $pending);
}

// Process pending cancels on each request
processPendingCancels();

switch ($action) {
    case 'balance':
        $result = callSmsHero(['action' => 'getBalance']);
        sendResponse($result);
        break;
        
    case 'getNumber':
        $service = $_POST['service'] ?? 'ds';
        $country = $_POST['country'] ?? 'CO';
        
        // Country code mapping for SMS Hero
        $countryMap = [
            'CO' => '33',  // Colombia
            'TH' => '52',  // Thailand
            'ID' => '6',   // Indonesia
            'BR' => '73',  // Brazil
            'IN' => '22',  // India
            'PK' => '66',  // Pakistan
            'BD' => '60',  // Bangladesh
            'US' => '12',  // USA
            'UK' => '14',  // UK
            'CA' => '36',  // Canada
            'AU' => '54',  // Australia
            'DE' => '43',  // Germany
            'FR' => '78',  // France
            'RU' => '0',   // Russia
            'CN' => '3',   // China
            'JP' => '50',  // Japan
            'KR' => '61',  // South Korea
            'MX' => '54',  // Mexico
            'TR' => '62',  // Turkey
            'EG' => '21'   // Egypt
        ];
        
        if (isset($countryMap[$country])) {
            $country = $countryMap[$country];
        }
        
        // Service mapping - comprehensive list
        $serviceMap = [
            'discord' => 'ds',
            'instagram' => 'ig',
            'whatsapp' => 'wa',
            'telegram' => 'tg',
            'facebook' => 'fb',
            'google' => 'go',
            'twitter' => 'tw',
            'tiktok' => 'tk',
            'snapchat' => 'sc',
            'amazon' => 'am',
            'netflix' => 'nf',
            'spotify' => 'sp',
            'uber' => 'ub',
            'paypal' => 'pp',
            'apple' => 'al',
            'microsoft' => 'mm',
            'linkedin' => 'ln',
            'pinterest' => 'pi',
            'reddit' => 're',
            'twitch' => 'tc',
            'steam' => 'st',
            'epicgames' => 'ep',
            'roblox' => 'rb',
            'youtube' => 'yo',
            'gmail' => 'gm',
            'yahoo' => 'yh',
            'outlook' => 'ot',
            'protonmail' => 'pm',
            'icloud' => 'ic',
            'vk' => 'vk',
            'ok' => 'ok',
            'wechat' => 'wc',
            'line' => 'li',
            'viber' => 'vi',
            'signal' => 'sg',
            'zoom' => 'zm',
            'teams' => 'tm',
            'slack' => 'sl',
            'skype' => 'sk',
            'tinder' => 'ti',
            'bumble' => 'bu',
            'hinge' => 'hi',
            'match' => 'ma',
            'ebay' => 'eb',
            'aliexpress' => 'ae',
            'shopify' => 'sh',
            'etsy' => 'et',
            'walmart' => 'wm',
            'target' => 'ta',
            'bestbuy' => 'bb',
            'hulu' => 'hu',
            'disney' => 'di',
            'hbo' => 'hb',
            'prime' => 'pr',
            'applemusic' => 'ap',
            'soundcloud' => 'so',
            'deezer' => 'dz',
            'tidal' => 'td',
            'pandora' => 'pa',
            'iheartradio' => 'ir',
            'audible' => 'au',
            'kindle' => 'ki',
            'goodreads' => 'gr',
            'strava' => 'sr',
            'nike' => 'ni',
            'adidas' => 'ad',
            'underarmour' => 'ua',
            'myfitnesspal' => 'mf',
            'fitbit' => 'fi',
            'garmin' => 'ga',
            'peloton' => 'pe',
            'classpass' => 'cp',
            'doordash' => 'dd',
            'grubhub' => 'gh',
            'ubereats' => 'ue',
            'postmates' => 'po',
            'instacart' => 'in',
            'shipt' => 'si',
            'gopuff' => 'gp',
            'lyft' => 'ly',
            'bird' => 'bi',
            'lime' => 'lm',
            'spin' => 'spn',
            'airbnb' => 'ab',
            'booking' => 'bk',
            'expedia' => 'ex',
            'hotels' => 'ho',
            'kayak' => 'ka',
            'priceline' => 'pl',
            'trivago' => 'tr',
            'tripadvisor' => 'tp',
            'yelp' => 'ye',
            'foursquare' => 'fs',
            'zillow' => 'zi',
            'realtor' => 'rl',
            'trulia' => 'tu',
            'apartments' => 'apts',
            'redfin' => 'rf',
            'opendoor' => 'od',
            'offerpad' => 'of',
            'carvana' => 'cv',
            'carmax' => 'cm',
            'autotrader' => 'at',
            'cars' => 'cars',
            'truecar' => 'tcar',
            'kbb' => 'kb',
            'edmunds' => 'ed',
            'cargurus' => 'cg',
            'bankofamerica' => 'boa',
            'chase' => 'ch',
            'wellsfargo' => 'wf',
            'citi' => 'ct',
            'capitalone' => 'co',
            'discover' => 'dc',
            'amex' => 'ax',
            'venmo' => 've',
            'cashapp' => 'ca',
            'zelle' => 'ze',
            'westernunion' => 'wu',
            'moneygram' => 'mg',
            'remitly' => 're',
            'wise' => 'wi',
            'revolut' => 'rv',
            'n26' => 'n2',
            'monzo' => 'mo',
            'starling' => 'st',
            'chime' => 'ci',
            'varo' => 'va',
            'sofi' => 'so',
            'ally' => 'al',
            'marcus' => 'ma',
            'betterment' => 'be',
            'wealthfront' => 'we',
            'robinhood' => 'ro',
            'webull' => 'wb',
            'etoro' => 'et',
            'coinbase' => 'cb',
            'binance' => 'bi',
            'kraken' => 'kr',
            'gemini' => 'ge',
            'blockfi' => 'bl',
            'celsius' => 'ce',
            'nexo' => 'ne',
            'crypto' => 'cr',
            'kucoin' => 'ku',
            'ftx' => 'ft',
            'huobi' => 'hb',
            'okx' => 'okx',
            'bybit' => 'by',
            'phemex' => 'ph',
            'deribit' => 'de',
            'bitmex' => 'bm',
            'bitfinex' => 'bf',
            'bitstamp' => 'bs',
            'bittrex' => 'bt',
            'poloniex' => 'po',
            'gate' => 'ga',
            'mexc' => 'me',
            'lbank' => 'lb'
        ];
        
        if (isset($serviceMap[$service])) {
            $service = $serviceMap[$service];
        }
        
        $result = callSmsHero([
            'action' => 'getNumber',
            'service' => $service,
            'country' => $country
        ]);
        
        sendResponse($result);
        break;
        
    case 'getStatus':
        $activationId = $_GET['id'] ?? '';
        if (empty($activationId)) {
            sendError('Activation ID required');
        }
        
        $result = callSmsHero([
            'action' => 'getStatus',
            'id' => $activationId
        ]);
        
        sendResponse($result);
        break;
        
    case 'cancel':
        $activationId = $_POST['id'] ?? '';
        if (empty($activationId)) {
            sendError('Activation ID required');
        }
        
        // Schedule cancel after 135 seconds (SMS-HERO requirement)
        $pending = loadJson('pending_cancels.json');
        
        $pending['pending'][] = [
            'id' => generateId(),
            'activationId' => sanitizeInput($activationId),
            'userId' => $_SESSION['user_id'] ?? 'unknown',
            'username' => $_SESSION['username'] ?? 'unknown',
            'scheduledAt' => date('Y-m-d H:i:s'),
            'executeAt' => date('Y-m-d H:i:s', time() + 135)
        ];
        
        saveJson('pending_cancels.json', $pending);
        
        logAction($_SESSION['user_id'] ?? 'unknown', $_SESSION['username'] ?? 'unknown', 'CANCEL_SCHEDULED', 'Cancel scheduled for activation: ' . $activationId);
        
        sendResponse([
            'success' => true,
            'message' => 'Cancel scheduled. Will execute after 135 seconds.',
            'scheduled' => true
        ]);
        break;
        
    case 'getPrices':
        $country = $_GET['country'] ?? '52';
        $result = callSmsHero([
            'action' => 'getPrices',
            'country' => $country
        ]);
        sendResponse($result);
        break;
        
    default:
        sendError('Invalid action: ' . $action);
}
?>
