<?php
require_once 'config.php';

$action = $_POST['action'] ?? '';

// Rate limiting for login attempts
if ($action === 'login' || $action === 'signup') {
    if (!checkRateLimit($action, 5, 300)) {
        sendError('Too many attempts. Please try again in 5 minutes.', 429);
    }
}

switch ($action) {
    // ========== USER SIGNUP ==========
    case 'signup':
        $username = trim($_POST['username'] ?? '');
        $fullname = trim($_POST['fullname'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        
        // Validation
        if (empty($username) || empty($fullname) || empty($phone) || empty($email) || empty($password)) {
            sendError('All fields are required');
        }
        
        // Username validation - alphanumeric and underscores only
        if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
            sendError('Username must be 3-20 characters, alphanumeric and underscores only');
        }
        
        // Email validation
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            sendError('Please enter a valid email address');
        }
        
        // Phone validation
        if (!preg_match('/^[0-9+\-\s()]{10,20}$/', $phone)) {
            sendError('Please enter a valid phone number');
        }
        
        // Password validation - minimum 8 characters
        if (strlen($password) < 8) {
            sendError('Password must be at least 8 characters');
        }
        
        // Check password strength
        if (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/', $password)) {
            sendError('Password must contain at least one uppercase letter, one lowercase letter, and one number');
        }
        
        $users = loadJson('users.json');
        
        // Check if username exists
        foreach ($users['users'] as $user) {
            if ($user['username'] === $username) {
                sendError('Username already taken. Please choose another.');
            }
            if ($user['email'] === $email) {
                sendError('Email already registered. Please use another email.');
            }
        }
        
        // Create new user
        $newUser = [
            'id' => generateId(),
            'username' => sanitizeInput($username),
            'password' => hashPassword($password),
            'fullname' => sanitizeInput($fullname),
            'phone' => sanitizeInput($phone),
            'email' => sanitizeInput($email),
            'balance' => 0,
            'active' => true,
            'createdAt' => date('Y-m-d H:i:s'),
            'totalPurchases' => 0,
            'totalSpent' => 0
        ];
        
        $users['users'][] = $newUser;
        
        if (saveJson('users.json', $users)) {
            logAction($newUser['id'], $username, 'SIGNUP', 'New user registered');
            logActivity($newUser['id'], $username, 'SIGNUP', 'Account created', 'signup');
            sendResponse([
                'success' => true,
                'message' => 'Account created successfully! Please login.'
            ]);
        } else {
            sendError('Failed to create account. Please try again.');
        }
        break;
        
    // ========== USER LOGIN ==========
    case 'login':
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $type = $_POST['type'] ?? 'user';
        
        if (empty($username) || empty($password)) {
            sendError('Username and password required');
        }
        
        if ($type === 'admin') {
            // Admin login
            $config = loadJson('config.json');
            if (!$config) {
                sendError('Configuration error');
            }
            
            if ($config['admin']['username'] === $username && verifyPassword($password, $config['admin']['password'])) {
                $_SESSION['logged_in'] = true;
                $_SESSION['type'] = 'admin';
                $_SESSION['username'] = sanitizeInput($username);
                $_SESSION['user_id'] = 'admin';
                
                logAction('admin', $username, 'LOGIN', 'Admin logged in');
                logActivity('admin', $username, 'LOGIN', 'Admin login successful', 'admin');
                
                sendResponse([
                    'success' => true,
                    'type' => 'admin',
                    'message' => 'Login successful'
                ]);
            } else {
                logAction('admin', $username, 'LOGIN_FAILED', 'Invalid admin credentials');
                sendError('Invalid username or password');
            }
        } else {
            // User login
            $usersData = loadJson('users.json');
            if (!$usersData) {
                sendError('User data error');
            }
            
            $foundUser = null;
            foreach ($usersData['users'] as $user) {
                if ($user['username'] === $username && verifyPassword($password, $user['password'])) {
                    $foundUser = $user;
                    break;
                }
            }
            
            if (!$foundUser) {
                logAction('unknown', $username, 'LOGIN_FAILED', 'Invalid user credentials');
                sendError('Invalid username or password');
            }
            
            if (!$foundUser['active']) {
                sendError('Account is deactivated. Contact admin.');
            }
            
            $_SESSION['logged_in'] = true;
            $_SESSION['type'] = 'user';
            $_SESSION['username'] = $foundUser['username'];
            $_SESSION['user_id'] = $foundUser['id'];
            
            // Don't send password to client
            unset($foundUser['password']);
            $_SESSION['user'] = $foundUser;
            
            logAction($foundUser['id'], $foundUser['username'], 'LOGIN', 'User logged in');
            logActivity($foundUser['id'], $foundUser['username'], 'LOGIN', 'User login successful', 'login');
            
            sendResponse([
                'success' => true,
                'type' => 'user',
                'user' => $foundUser,
                'message' => 'Login successful'
            ]);
        }
        break;
        
    // ========== LOGOUT ==========
    case 'logout':
        if (isset($_SESSION['user_id'])) {
            logAction($_SESSION['user_id'], $_SESSION['username'] ?? 'unknown', 'LOGOUT', 'User logged out');
            logActivity($_SESSION['user_id'], $_SESSION['username'] ?? 'unknown', 'LOGOUT', 'User logout', 'logout');
        }
        session_destroy();
        sendResponse(['success' => true, 'message' => 'Logged out']);
        break;
        
    // ========== CHECK SESSION ==========
    case 'check':
        if (isset($_SESSION['logged_in']) && $_SESSION['logged_in']) {
            $response = [
                'success' => true,
                'type' => $_SESSION['type'],
                'username' => $_SESSION['username']
            ];
            
            if ($_SESSION['type'] === 'user' && isset($_SESSION['user_id'])) {
                // Refresh user data
                $usersData = loadJson('users.json');
                foreach ($usersData['users'] as $user) {
                    if ($user['id'] === $_SESSION['user_id']) {
                        unset($user['password']);
                        $response['user'] = $user;
                        $_SESSION['user'] = $user;
                        break;
                    }
                }
            }
            
            sendResponse($response);
        } else {
            sendResponse(['success' => false]);
        }
        break;
        
    // ========== CHECK USERNAME AVAILABILITY ==========
    case 'checkUsername':
        $username = trim($_POST['username'] ?? '');
        
        if (empty($username)) {
            sendResponse(['available' => false]);
        }
        
        // Validate username format
        if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
            sendResponse(['available' => false]);
        }
        
        $users = loadJson('users.json');
        foreach ($users['users'] as $user) {
            if ($user['username'] === $username) {
                sendResponse(['available' => false]);
            }
        }
        
        sendResponse(['available' => true]);
        break;
        
    default:
        sendError('Invalid action');
}
?>
