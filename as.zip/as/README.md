# Apex SMS - Premium SMS Verification Service

A modern, secure SMS verification platform built with PHP, HTML, CSS, and JavaScript. Powered by SMS-HERO API.

## Features

### User Features
- **User Registration & Login** - Create account with username, full name, phone, email, and password
- **Balance System** - PKR-based wallet system instead of daily limits
- **Topup System** - Request topups via WhatsApp integration
- **Service Selection** - Choose from 100+ services (Discord, Instagram, WhatsApp, etc.)
- **Country Selection** - Numbers from 50+ countries
- **Real-time Code Checking** - Automatic SMS code detection
- **Number History** - View all past purchases
- **Help Section** - Tutorial video and WhatsApp support

### Admin Features
- **Dashboard** - View system statistics and recent activity
- **User Management** - Create, edit, delete users, add balance
- **Service Management** - Add services with icons, set prices per country
- **Topup Management** - Approve/reject topup requests
- **Activity Tracking** - Filter user activities by type, date, username
- **System Logs** - Track all system actions
- **Settings** - Configure API keys, WhatsApp number, tutorial video

### Security Features
- Argon2id password hashing
- Rate limiting on login/signup
- XSS protection with input sanitization
- CSRF token support
- Security headers (X-Frame-Options, X-Content-Type-Options, etc.)
- Automatic data backups
- .htaccess protection for sensitive files

## Installation

1. **Upload files to your web server**
   - Upload all files to your web root directory
   - Ensure PHP 7.4+ is installed

2. **Set permissions**
   ```bash
   chmod 755 data/
   chmod 644 data/*.json
   ```

3. **Configure admin password**
   - Default admin credentials:
     - Username: `admin`
     - Password: `admin123`
   - **IMPORTANT:** Change the admin password immediately after first login!

4. **Configure SMS-HERO API**
   - Login to admin panel
   - Go to Settings
   - Enter your SMS-HERO API key
   - Set your WhatsApp number for topup requests
   - Add tutorial video URL (optional)

5. **Add services**
   - Go to Services tab
   - Click "Add Service"
   - Enter service name and SMS-HERO code
   - Select an icon
   - Add countries with prices

## File Structure

```
apexsms/
├── api/
│   ├── config.php      # Configuration and helper functions
│   ├── auth.php        # Authentication API
│   ├── manage.php      # Management API
│   └── smshero.php     # SMS-HERO integration
├── css/
│   └── style.css       # Main stylesheet (Green/Black/White theme)
├── data/
│   ├── config.json     # System configuration
│   ├── users.json      # User data
│   ├── services.json   # Services and pricing
│   ├── numbers.json    # Active and history numbers
│   ├── topups.json     # Topup requests
│   ├── logs.json       # System logs
│   ├── activity.json   # User activities
│   └── pending_cancels.json  # Pending cancellations
├── index.html          # Homepage
├── login.html          # User login/signup
├── dashboard.html      # User dashboard
├── admin-login.html    # Admin login
├── admin.html          # Admin panel
├── .htaccess           # Security configuration
└── README.md           # This file
```

## SMS-HERO Service Codes

Common service codes for SMS-HERO API:

| Service | Code |
|---------|------|
| Discord | ds |
| Instagram | ig |
| WhatsApp | wa |
| Telegram | tg |
| Facebook | fb |
| Google | go |
| Twitter/X | tw |
| TikTok | tk |
| Snapchat | sc |
| Amazon | am |
| Netflix | nf |
| Spotify | sp |

## Country Codes

Common country codes for SMS-HERO API:

| Country | Code |
|---------|------|
| Pakistan | 66 |
| USA | 12 |
| UK | 14 |
| Canada | 36 |
| India | 22 |
| Russia | 0 |
| China | 3 |
| Indonesia | 6 |
| Thailand | 52 |
| Colombia | 33 |

## 135-Second Cancel/Replace Delay

SMS-HERO requires a 135-second delay before canceling or replacing a number. The system automatically:

1. Schedules cancel/replace requests
2. Waits for 135 seconds
3. Executes the cancel on SMS-HERO
4. Prevents double-charging

## Security Notes

- Change default admin password immediately
- Keep your SMS-HERO API key secure
- Regularly backup the `data/` directory
- Enable HTTPS on your server
- Monitor logs for suspicious activity

## Support

For support, contact us on WhatsApp or check the tutorial video in the Help section.

## License

This software is for personal/commercial use. All rights reserved.

---

**Powered by SMS-HERO API** | **Theme: Green, Black & White**
