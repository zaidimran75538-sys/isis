<?php
require_once 'config.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$isAdmin = isset($_SESSION['type']) && $_SESSION['type'] === 'admin';
$currentUserId = $_SESSION['user_id'] ?? '';

switch ($action) {
    // ========== CONFIG (Admin only) ==========
    case 'getConfig':
        requireAdmin();
        $config = loadJson('config.json');
        // Don't expose full API key
        if ($config && !empty($config['api']['key'])) {
            $key = $config['api']['key'];
            $config['api']['key_masked'] = str_repeat('*', strlen($key) - 4) . substr($key, -4);
        }
        sendResponse(['success' => true, 'config' => $config]);
        break;
        
    case 'updateConfig':
        requireAdmin();
        
        $config = loadJson('config.json');
        
        // Update API key if provided
        if (isset($_POST['apiKey'])) {
            $apiKey = trim($_POST['apiKey']);
            if (!empty($apiKey)) {
                $config['api']['key'] = sanitizeInput($apiKey);
            }
        }
        
        // Update API URL if provided
        if (isset($_POST['apiUrl'])) {
            $config['api']['url'] = sanitizeInput(trim($_POST['apiUrl']));
        }
        
        // Update WhatsApp number
        if (isset($_POST['whatsappNumber'])) {
            $config['settings']['whatsappNumber'] = sanitizeInput(trim($_POST['whatsappNumber']));
        }
        
        // Update tutorial video
        if (isset($_POST['tutorialVideo'])) {
            $config['settings']['tutorialVideo'] = sanitizeInput(trim($_POST['tutorialVideo']));
        }
        
        // Update support message
        if (isset($_POST['supportMessage'])) {
            $config['settings']['supportMessage'] = sanitizeInput(trim($_POST['supportMessage']));
        }
        
        // Update settings
        if (isset($_POST['numberExpiry'])) {
            $config['settings']['numberExpiry'] = intval($_POST['numberExpiry']);
        }
        
        // Handle admin password change
        if (isset($_POST['currentPassword']) && isset($_POST['newAdminPassword'])) {
            $currentPassword = $_POST['currentPassword'];
            $newPassword = $_POST['newAdminPassword'];
            
            if (strlen($newPassword) < 8) {
                sendError('New password must be at least 8 characters');
            }
            
            if (!verifyPassword($currentPassword, $config['admin']['password'])) {
                sendError('Current password is incorrect');
            }
            
            $config['admin']['password'] = hashPassword($newPassword);
            logAction('admin', $_SESSION['username'], 'PASSWORD_CHANGE', 'Admin password changed');
        }
        
        if (saveJson('config.json', $config)) {
            logAction('admin', $_SESSION['username'], 'UPDATE_CONFIG', 'Settings updated');
            sendResponse(['success' => true, 'message' => 'Settings saved']);
        } else {
            sendError('Failed to save settings');
        }
        break;
        
    // ========== COUNTRIES (Admin only) ==========
    case 'getCountries':
        requireAdmin();
        $countries = loadJson('countries.json');
        if (!$countries) {
            // Initialize with default countries
            $countries = ['countries' => getDefaultCountries()];
            saveJson('countries.json', $countries);
        }
        sendResponse(['success' => true, 'countries' => $countries['countries'] ?? []]);
        break;
        
    case 'addCountry':
        requireAdmin();
        
        $code = trim($_POST['code'] ?? '');
        $name = trim($_POST['name'] ?? '');
        $smsHeroCode = trim($_POST['smsHeroCode'] ?? '');
        $flag = trim($_POST['flag'] ?? '');
        $active = filter_var($_POST['active'] ?? 'true', FILTER_VALIDATE_BOOLEAN);
        
        if (empty($code) || empty($name) || empty($smsHeroCode)) {
            sendError('Country code, name, and SMS-HERO code are required');
        }
        
        $countries = loadJson('countries.json');
        if (!$countries) {
            $countries = ['countries' => []];
        }
        
        // Check if country already exists
        foreach ($countries['countries'] as $country) {
            if ($country['code'] === $code) {
                sendError('Country code already exists');
            }
        }
        
        $newCountry = [
            'id' => generateId(),
            'code' => sanitizeInput($code),
            'name' => sanitizeInput($name),
            'smsHeroCode' => sanitizeInput($smsHeroCode),
            'flag' => sanitizeInput($flag),
            'active' => $active,
            'createdAt' => date('Y-m-d H:i:s')
        ];
        
        $countries['countries'][] = $newCountry;
        
        if (saveJson('countries.json', $countries)) {
            logAction('admin', $_SESSION['username'], 'ADD_COUNTRY', 'Added country: ' . $name);
            sendResponse(['success' => true, 'country' => $newCountry]);
        } else {
            sendError('Failed to add country');
        }
        break;
        
    case 'updateCountry':
        requireAdmin();
        
        $countryId = $_POST['id'] ?? '';
        if (empty($countryId)) {
            sendError('Country ID required');
        }
        
        $countries = loadJson('countries.json');
        $found = false;
        
        foreach ($countries['countries'] as &$country) {
            if ($country['id'] === $countryId) {
                if (isset($_POST['name'])) $country['name'] = sanitizeInput(trim($_POST['name']));
                if (isset($_POST['smsHeroCode'])) $country['smsHeroCode'] = sanitizeInput(trim($_POST['smsHeroCode']));
                if (isset($_POST['flag'])) $country['flag'] = sanitizeInput(trim($_POST['flag']));
                if (isset($_POST['active'])) $country['active'] = filter_var($_POST['active'], FILTER_VALIDATE_BOOLEAN);
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            sendError('Country not found');
        }
        
        if (saveJson('countries.json', $countries)) {
            logAction('admin', $_SESSION['username'], 'UPDATE_COUNTRY', 'Updated country: ' . $countryId);
            sendResponse(['success' => true]);
        } else {
            sendError('Failed to update country');
        }
        break;
        
    case 'deleteCountry':
        requireAdmin();
        
        $countryId = $_POST['id'] ?? '';
        if (empty($countryId)) {
            sendError('Country ID required');
        }
        
        $countries = loadJson('countries.json');
        $countries['countries'] = array_filter($countries['countries'], function($c) use ($countryId) {
            return $c['id'] !== $countryId;
        });
        $countries['countries'] = array_values($countries['countries']);
        
        if (saveJson('countries.json', $countries)) {
            logAction('admin', $_SESSION['username'], 'DELETE_COUNTRY', 'Deleted country: ' . $countryId);
            sendResponse(['success' => true]);
        } else {
            sendError('Failed to delete country');
        }
        break;
        
    // ========== USERS ==========
    case 'getUsers':
        requireAdmin();
        $users = loadJson('users.json');
        // Remove passwords from response
        $safeUsers = [];
        foreach ($users['users'] as $user) {
            unset($user['password']);
            $safeUsers[] = $user;
        }
        sendResponse(['success' => true, 'users' => $safeUsers]);
        break;
        
    case 'getUser':
        requireAuth();
        $userId = $_GET['id'] ?? $currentUserId;
        
        if (!$isAdmin && $userId !== $currentUserId) {
            sendError('Unauthorized', 403);
        }
        
        $users = loadJson('users.json');
        foreach ($users['users'] as $user) {
            if ($user['id'] === $userId) {
                unset($user['password']);
                sendResponse(['success' => true, 'user' => $user]);
            }
        }
        sendError('User not found');
        break;
        
    case 'createUser':
        requireAdmin();
        
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $fullname = trim($_POST['fullname'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $email = trim($_POST['email'] ?? '');
        
        if (empty($username) || empty($password) || empty($fullname)) {
            sendError('Username, password and full name required');
        }
        
        // Validate username
        if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $username)) {
            sendError('Username must be 3-20 characters, alphanumeric and underscores only');
        }
        
        // Validate password
        if (strlen($password) < 8) {
            sendError('Password must be at least 8 characters');
        }
        
        $users = loadJson('users.json');
        
        // Check if username exists
        foreach ($users['users'] as $user) {
            if ($user['username'] === $username) {
                sendError('Username already exists');
            }
        }
        
        $newUser = [
            'id' => generateId(),
            'username' => sanitizeInput($username),
            'password' => hashPassword($password),
            'fullname' => sanitizeInput($fullname),
            'phone' => sanitizeInput($phone),
            'email' => sanitizeInput($email),
            'balance' => floatval($_POST['balance'] ?? 0),
            'active' => true,
            'createdAt' => date('Y-m-d H:i:s'),
            'totalPurchases' => 0,
            'totalSpent' => 0
        ];
        
        $users['users'][] = $newUser;
        
        if (saveJson('users.json', $users)) {
            logAction('admin', $_SESSION['username'], 'CREATE_USER', 'Created user: ' . $username);
            sendResponse(['success' => true, 'user' => $newUser]);
        } else {
            sendError('Failed to create user');
        }
        break;
        
    case 'updateUser':
        requireAdmin();
        
        $userId = $_POST['id'] ?? '';
        if (empty($userId)) {
            sendError('User ID required');
        }
        
        $users = loadJson('users.json');
        $found = false;
        $oldUser = null;
        
        foreach ($users['users'] as &$user) {
            if ($user['id'] === $userId) {
                $oldUser = $user;
                if (isset($_POST['fullname'])) $user['fullname'] = sanitizeInput(trim($_POST['fullname']));
                if (isset($_POST['email'])) $user['email'] = sanitizeInput(trim($_POST['email']));
                if (isset($_POST['phone'])) $user['phone'] = sanitizeInput(trim($_POST['phone']));
                if (!empty($_POST['password'])) $user['password'] = hashPassword($_POST['password']);
                if (isset($_POST['active'])) $user['active'] = filter_var($_POST['active'], FILTER_VALIDATE_BOOLEAN);
                
                // Handle balance addition
                if (isset($_POST['addBalance'])) {
                    $addBalance = floatval($_POST['addBalance']);
                    if ($addBalance > 0) {
                        $user['balance'] = ($user['balance'] ?? 0) + $addBalance;
                        
                        // Add topup record
                        $topups = loadJson('topups.json');
                        $topups['requests'][] = [
                            'id' => generateId(),
                            'userId' => $userId,
                            'amount' => $addBalance,
                            'status' => 'completed',
                            'type' => 'admin_added',
                            'createdAt' => date('Y-m-d H:i:s'),
                            'completedAt' => date('Y-m-d H:i:s')
                        ];
                        saveJson('topups.json', $topups);
                        
                        logAction('admin', $_SESSION['username'], 'ADD_BALANCE', 'Added PKR ' . $addBalance . ' to user: ' . $user['username']);
                    }
                }
                
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            sendError('User not found');
        }
        
        if (saveJson('users.json', $users)) {
            logAction('admin', $_SESSION['username'], 'UPDATE_USER', 'Updated user: ' . $userId);
            sendResponse(['success' => true]);
        } else {
            sendError('Failed to update user');
        }
        break;
        
    case 'deleteUser':
        requireAdmin();
        
        $userId = $_POST['id'] ?? '';
        if (empty($userId)) {
            sendError('User ID required');
        }
        
        $users = loadJson('users.json');
        $users['users'] = array_filter($users['users'], function($u) use ($userId) {
            return $u['id'] !== $userId;
        });
        $users['users'] = array_values($users['users']);
        
        if (saveJson('users.json', $users)) {
            logAction('admin', $_SESSION['username'], 'DELETE_USER', 'Deleted user: ' . $userId);
            sendResponse(['success' => true]);
        } else {
            sendError('Failed to delete user');
        }
        break;
        
    // ========== TOPUPS ==========
    case 'requestTopup':
        requireAuth();
        
        $amount = floatval($_POST['amount'] ?? 0);
        
        if ($amount < 100) {
            sendError('Minimum topup amount is PKR 100');
        }
        
        if ($amount > 50000) {
            sendError('Maximum topup amount is PKR 50,000');
        }
        
        $topups = loadJson('topups.json');
        
        $topupRequest = [
            'id' => generateId(),
            'userId' => $currentUserId,
            'username' => $_SESSION['username'],
            'amount' => $amount,
            'status' => 'pending',
            'type' => 'user_request',
            'createdAt' => date('Y-m-d H:i:s')
        ];
        
        $topups['requests'][] = $topupRequest;
        
        if (saveJson('topups.json', $topups)) {
            logAction($currentUserId, $_SESSION['username'], 'TOPUP_REQUEST', 'Requested topup of PKR ' . $amount);
            logActivity($currentUserId, $_SESSION['username'], 'TOPUP_REQUEST', 'Requested topup of PKR ' . $amount, 'dashboard');
            sendResponse([
                'success' => true, 
                'topup' => $topupRequest,
                'message' => 'Topup request submitted!'
            ]);
        } else {
            sendError('Failed to submit topup request');
        }
        break;
        
    case 'getTopups':
        requireAuth();
        
        $topups = loadJson('topups.json');
        
        if ($isAdmin) {
            // Admin sees all pending and recent topups
            $requests = $topups['requests'] ?? [];
            // Add user info to each request
            $users = loadJson('users.json');
            foreach ($requests as &$req) {
                foreach ($users['users'] as $user) {
                    if ($user['id'] === $req['userId']) {
                        $req['userFullname'] = $user['fullname'];
                        $req['userPhone'] = $user['phone'];
                        $req['userEmail'] = $user['email'];
                        break;
                    }
                }
            }
            sendResponse(['success' => true, 'topups' => array_reverse($requests)]);
        } else {
            // User sees only their topups
            $userTopups = array_filter($topups['requests'] ?? [], function($t) use ($currentUserId) {
                return $t['userId'] === $currentUserId;
            });
            sendResponse(['success' => true, 'topups' => array_values(array_reverse($userTopups))]);
        }
        break;
        
    case 'approveTopup':
        requireAdmin();
        
        $topupId = $_POST['topupId'] ?? '';
        
        if (empty($topupId)) {
            sendError('Topup ID required');
        }
        
        $topups = loadJson('topups.json');
        $found = false;
        
        foreach ($topups['requests'] as &$topup) {
            if ($topup['id'] === $topupId && $topup['status'] === 'pending') {
                $topup['status'] = 'completed';
                $topup['completedAt'] = date('Y-m-d H:i:s');
                $topup['approvedBy'] = $_SESSION['username'];
                
                // Add balance to user
                $users = loadJson('users.json');
                foreach ($users['users'] as &$user) {
                    if ($user['id'] === $topup['userId']) {
                        $user['balance'] = ($user['balance'] ?? 0) + $topup['amount'];
                        break;
                    }
                }
                saveJson('users.json', $users);
                
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            sendError('Topup request not found or already processed');
        }
        
        if (saveJson('topups.json', $topups)) {
            logAction('admin', $_SESSION['username'], 'APPROVE_TOPUP', 'Approved topup: ' . $topupId);
            sendResponse(['success' => true, 'message' => 'Topup approved successfully']);
        } else {
            sendError('Failed to approve topup');
        }
        break;
        
    case 'rejectTopup':
        requireAdmin();
        
        $topupId = $_POST['topupId'] ?? '';
        
        if (empty($topupId)) {
            sendError('Topup ID required');
        }
        
        $topups = loadJson('topups.json');
        $found = false;
        
        foreach ($topups['requests'] as &$topup) {
            if ($topup['id'] === $topupId && $topup['status'] === 'pending') {
                $topup['status'] = 'rejected';
                $topup['rejectedAt'] = date('Y-m-d H:i:s');
                $topup['rejectedBy'] = $_SESSION['username'];
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            sendError('Topup request not found or already processed');
        }
        
        if (saveJson('topups.json', $topups)) {
            logAction('admin', $_SESSION['username'], 'REJECT_TOPUP', 'Rejected topup: ' . $topupId);
            sendResponse(['success' => true, 'message' => 'Topup rejected']);
        } else {
            sendError('Failed to reject topup');
        }
        break;
        
    // ========== SERVICES ==========
    case 'getServices':
        $services = loadJson('services.json');
        sendResponse(['success' => true, 'services' => $services['services'] ?? []]);
        break;
        
    case 'addService':
        requireAdmin();
        
        $name = trim($_POST['name'] ?? '');
        $code = trim($_POST['code'] ?? '');
        $icon = trim($_POST['icon'] ?? '');
        $description = trim($_POST['description'] ?? '');
        
        if (empty($name) || empty($code)) {
            sendError('Service name and code required');
        }
        
        $services = loadJson('services.json');
        
        // Check if code exists
        foreach ($services['services'] as $service) {
            if ($service['code'] === $code) {
                sendError('Service code already exists');
            }
        }
        
        $newService = [
            'id' => generateId(),
            'name' => sanitizeInput($name),
            'code' => sanitizeInput($code),
            'icon' => sanitizeInput($icon),
            'description' => sanitizeInput($description),
            'active' => true,
            'numbers' => [],
            'createdAt' => date('Y-m-d H:i:s')
        ];
        
        $services['services'][] = $newService;
        
        if (saveJson('services.json', $services)) {
            logAction('admin', $_SESSION['username'], 'ADD_SERVICE', 'Added service: ' . $name);
            sendResponse(['success' => true, 'service' => $newService]);
        } else {
            sendError('Failed to add service');
        }
        break;
        
    case 'updateService':
        requireAdmin();
        
        $serviceId = $_POST['id'] ?? '';
        
        if (empty($serviceId)) {
            sendError('Service ID required');
        }
        
        $services = loadJson('services.json');
        $found = false;
        
        foreach ($services['services'] as &$service) {
            if ($service['id'] === $serviceId) {
                if (isset($_POST['name'])) $service['name'] = sanitizeInput(trim($_POST['name']));
                if (isset($_POST['code'])) $service['code'] = sanitizeInput(trim($_POST['code']));
                if (isset($_POST['icon'])) $service['icon'] = sanitizeInput(trim($_POST['icon']));
                if (isset($_POST['description'])) $service['description'] = sanitizeInput(trim($_POST['description']));
                if (isset($_POST['active'])) $service['active'] = filter_var($_POST['active'], FILTER_VALIDATE_BOOLEAN);
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            sendError('Service not found');
        }
        
        if (saveJson('services.json', $services)) {
            logAction('admin', $_SESSION['username'], 'UPDATE_SERVICE', 'Updated service: ' . $serviceId);
            sendResponse(['success' => true]);
        } else {
            sendError('Failed to update service');
        }
        break;
        
    case 'deleteService':
        requireAdmin();
        
        $serviceId = $_POST['id'] ?? '';
        
        if (empty($serviceId)) {
            sendError('Service ID required');
        }
        
        $services = loadJson('services.json');
        $services['services'] = array_filter($services['services'], function($s) use ($serviceId) {
            return $s['id'] !== $serviceId;
        });
        $services['services'] = array_values($services['services']);
        
        if (saveJson('services.json', $services)) {
            logAction('admin', $_SESSION['username'], 'DELETE_SERVICE', 'Deleted service: ' . $serviceId);
            sendResponse(['success' => true]);
        } else {
            sendError('Failed to delete service');
        }
        break;
        
    case 'addServiceNumber':
        requireAdmin();
        
        $serviceId = $_POST['serviceId'] ?? '';
        $countryCode = trim($_POST['countryCode'] ?? '');
        $countryName = trim($_POST['countryName'] ?? '');
        $price = floatval($_POST['price'] ?? 0);
        $smsHeroCode = trim($_POST['smsHeroCode'] ?? '');
        
        if (empty($serviceId) || empty($countryCode) || $price <= 0) {
            sendError('Service ID, country code, and valid price required');
        }
        
        $services = loadJson('services.json');
        $found = false;
        
        foreach ($services['services'] as &$service) {
            if ($service['id'] === $serviceId) {
                // Check if country already exists
                foreach ($service['numbers'] as &$num) {
                    if ($num['countryCode'] === $countryCode) {
                        $num['price'] = $price;
                        $num['smsHeroCode'] = sanitizeInput($smsHeroCode);
                        $num['countryName'] = sanitizeInput($countryName);
                        $found = true;
                        break 2;
                    }
                }
                
                // Add new country
                $service['numbers'][] = [
                    'countryCode' => sanitizeInput($countryCode),
                    'countryName' => sanitizeInput($countryName),
                    'price' => $price,
                    'smsHeroCode' => sanitizeInput($smsHeroCode),
                    'active' => true
                ];
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            sendError('Service not found');
        }
        
        if (saveJson('services.json', $services)) {
            logAction('admin', $_SESSION['username'], 'ADD_SERVICE_NUMBER', 'Added number for ' . $countryCode . ' to service: ' . $serviceId);
            sendResponse(['success' => true]);
        } else {
            sendError('Failed to add service number');
        }
        break;
        
    case 'removeServiceNumber':
        requireAdmin();
        
        $serviceId = $_POST['serviceId'] ?? '';
        $countryCode = $_POST['countryCode'] ?? '';
        
        if (empty($serviceId) || empty($countryCode)) {
            sendError('Service ID and country code required');
        }
        
        $services = loadJson('services.json');
        $found = false;
        
        foreach ($services['services'] as &$service) {
            if ($service['id'] === $serviceId) {
                $service['numbers'] = array_filter($service['numbers'], function($n) use ($countryCode) {
                    return $n['countryCode'] !== $countryCode;
                });
                $service['numbers'] = array_values($service['numbers']);
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            sendError('Service not found');
        }
        
        if (saveJson('services.json', $services)) {
            logAction('admin', $_SESSION['username'], 'REMOVE_SERVICE_NUMBER', 'Removed number for ' . $countryCode . ' from service: ' . $serviceId);
            sendResponse(['success' => true]);
        } else {
            sendError('Failed to remove service number');
        }
        break;
        
    // ========== NUMBERS ==========
    case 'getNumbers':
        requireAuth();
        
        $numbers = loadJson('numbers.json');
        
        if ($isAdmin) {
            sendResponse(['success' => true, 'numbers' => $numbers]);
        } else {
            // Filter for current user only
            $userActive = array_filter($numbers['active'] ?? [], function($n) use ($currentUserId) {
                return $n['userId'] === $currentUserId;
            });
            $userHistory = array_filter($numbers['history'] ?? [], function($n) use ($currentUserId) {
                return $n['userId'] === $currentUserId;
            });
            
            sendResponse([
                'success' => true,
                'numbers' => [
                    'active' => array_values($userActive),
                    'history' => array_values($userHistory)
                ]
            ]);
        }
        break;
        
    case 'addNumber':
        requireAuth();
        
        $number = $_POST['number'] ?? '';
        $activationId = $_POST['activationId'] ?? '';
        $country = $_POST['country'] ?? '';
        $service = $_POST['service'] ?? '';
        $price = floatval($_POST['price'] ?? 0);
        $expiresAt = $_POST['expiresAt'] ?? date('Y-m-d H:i:s', time() + 900);
        
        if (empty($number) || empty($activationId) || empty($service)) {
            sendError('Number, activation ID, and service required');
        }
        
        // Check user balance
        $users = loadJson('users.json');
        $currentUser = null;
        foreach ($users['users'] as $user) {
            if ($user['id'] === $currentUserId) {
                $currentUser = $user;
                break;
            }
        }
        
        if (!$currentUser) {
            sendError('User not found');
        }
        
        if (($currentUser['balance'] ?? 0) < $price) {
            sendError('Insufficient balance. Please topup your account.');
        }
        
        // Deduct balance immediately
        foreach ($users['users'] as &$user) {
            if ($user['id'] === $currentUserId) {
                $user['balance'] -= $price;
                $user['totalPurchases'] = ($user['totalPurchases'] ?? 0) + 1;
                $user['totalSpent'] = ($user['totalSpent'] ?? 0) + $price;
                break;
            }
        }
        saveJson('users.json', $users);
        
        $numbers = loadJson('numbers.json');
        
        // Check max active numbers (5)
        $userActiveCount = count(array_filter($numbers['active'] ?? [], function($n) use ($currentUserId) {
            return $n['userId'] === $currentUserId;
        }));
        
        if ($userActiveCount >= 5) {
            // Refund balance
            foreach ($users['users'] as &$user) {
                if ($user['id'] === $currentUserId) {
                    $user['balance'] += $price;
                    $user['totalPurchases']--;
                    $user['totalSpent'] -= $price;
                    break;
                }
            }
            saveJson('users.json', $users);
            sendError('You can only have 5 active numbers at a time');
        }
        
        $newNumber = [
            'id' => generateId(),
            'number' => sanitizeInput($number),
            'activationId' => sanitizeInput($activationId),
            'userId' => $currentUserId,
            'username' => $_SESSION['username'] ?? '',
            'country' => sanitizeInput($country),
            'service' => sanitizeInput($service),
            'price' => $price,
            'code' => null,
            'status' => 'pending',
            'createdAt' => date('Y-m-d H:i:s'),
            'expiresAt' => $expiresAt,
            'charged' => true,
            'codeReceived' => false,
            'cancelled' => false
        ];
        
        $numbers['active'][] = $newNumber;
        
        if (saveJson('numbers.json', $numbers)) {
            logAction($currentUserId, $_SESSION['username'], 'ADD_NUMBER', 'Bought number: ' . $number . ' for PKR ' . $price);
            logActivity($currentUserId, $_SESSION['username'], 'ADD_NUMBER', 'Bought number: ' . $number . ' for PKR ' . $price, 'dashboard');
            sendResponse(['success' => true, 'number' => $newNumber]);
        } else {
            sendError('Failed to save number');
        }
        break;
        
    case 'replaceNumber':
        requireAuth();
        
        $oldId = $_POST['oldId'] ?? '';
        $number = $_POST['number'] ?? '';
        $activationId = $_POST['activationId'] ?? '';
        $country = $_POST['country'] ?? '';
        $service = $_POST['service'] ?? '';
        $price = floatval($_POST['price'] ?? 0);
        $expiresAt = $_POST['expiresAt'] ?? date('Y-m-d H:i:s', time() + 900);
        
        if (empty($oldId) || empty($number) || empty($activationId)) {
            sendError('Missing required parameters');
        }
        
        $numbers = loadJson('numbers.json');
        
        // Find and remove old number
        $found = false;
        foreach ($numbers['active'] as $key => $num) {
            if ($num['id'] === $oldId) {
                // Check ownership
                if (!$isAdmin && $num['userId'] !== $currentUserId) {
                    sendError('Unauthorized', 403);
                }
                
                // Move old number to history as replaced (no refund for replace)
                $oldNumber = $num;
                $oldNumber['status'] = 'replaced';
                unset($numbers['active'][$key]);
                array_unshift($numbers['history'], $oldNumber);
                $found = true;
                break;
            }
        }
        
        if (!$found) {
            sendError('Old number not found');
        }
        
        // Charge for new number
        $users = loadJson('users.json');
        foreach ($users['users'] as &$user) {
            if ($user['id'] === $currentUserId) {
                if (($user['balance'] ?? 0) < $price) {
                    sendError('Insufficient balance for replacement');
                }
                $user['balance'] -= $price;
                $user['totalPurchases'] = ($user['totalPurchases'] ?? 0) + 1;
                $user['totalSpent'] = ($user['totalSpent'] ?? 0) + $price;
                break;
            }
        }
        saveJson('users.json', $users);
        
        // Add new number
        $newNumber = [
            'id' => generateId(),
            'number' => sanitizeInput($number),
            'activationId' => sanitizeInput($activationId),
            'userId' => $currentUserId,
            'username' => $_SESSION['username'] ?? '',
            'country' => sanitizeInput($country),
            'service' => sanitizeInput($service),
            'price' => $price,
            'code' => null,
            'status' => 'pending',
            'createdAt' => date('Y-m-d H:i:s'),
            'expiresAt' => $expiresAt,
            'charged' => true,
            'codeReceived' => false,
            'cancelled' => false
        ];
        
        $numbers['active'][] = $newNumber;
        $numbers['active'] = array_values($numbers['active']);
        
        // Keep only last 500 history items
        if (count($numbers['history']) > 500) {
            $numbers['history'] = array_slice($numbers['history'], 0, 500);
        }
        
        if (saveJson('numbers.json', $numbers)) {
            logAction($currentUserId, $_SESSION['username'], 'REPLACE_NUMBER', 'Replaced with number: ' . $number . ' for PKR ' . $price);
            logActivity($currentUserId, $_SESSION['username'], 'REPLACE_NUMBER', 'Replaced with number: ' . $number . ' for PKR ' . $price, 'dashboard');
            sendResponse(['success' => true, 'number' => $newNumber]);
        } else {
            sendError('Failed to replace number');
        }
        break;
        
    case 'updateNumber':
        requireAuth();
        
        $numberId = $_POST['id'] ?? '';
        $code = $_POST['code'] ?? null;
        $status = $_POST['status'] ?? null;
        
        $numbers = loadJson('numbers.json');
        
        foreach ($numbers['active'] as &$num) {
            if ($num['id'] === $numberId) {
                // Check ownership
                if (!$isAdmin && $num['userId'] !== $currentUserId) {
                    sendError('Unauthorized', 403);
                }
                
                if ($code !== null) {
                    $num['code'] = sanitizeInput($code);
                    $num['codeReceived'] = true;
                }
                if ($status !== null) $num['status'] = sanitizeInput($status);
                
                saveJson('numbers.json', $numbers);
                sendResponse(['success' => true]);
            }
        }
        
        sendError('Number not found');
        break;
        
    case 'moveToHistory':
        requireAuth();
        
        $numberId = $_POST['id'] ?? '';
        $status = $_POST['status'] ?? 'expired';
        
        $numbers = loadJson('numbers.json');
        $foundNumber = null;
        
        foreach ($numbers['active'] as $key => $num) {
            if ($num['id'] === $numberId) {
                // Check ownership
                if (!$isAdmin && $num['userId'] !== $currentUserId) {
                    sendError('Unauthorized', 403);
                }
                
                $foundNumber = $num;
                $foundNumber['status'] = sanitizeInput($status);
                unset($numbers['active'][$key]);
                break;
            }
        }
        
        if (!$foundNumber) {
            sendError('Number not found');
        }
        
        $numbers['active'] = array_values($numbers['active']);
        array_unshift($numbers['history'], $foundNumber);
        
        // Keep only last 500 history items
        if (count($numbers['history']) > 500) {
            $numbers['history'] = array_slice($numbers['history'], 0, 500);
        }
        
        if (saveJson('numbers.json', $numbers)) {
            logAction($currentUserId, $_SESSION['username'], 'MOVE_HISTORY', 'Number ' . $foundNumber['number'] . ' moved to history: ' . $status);
            logActivity($currentUserId, $_SESSION['username'], 'CANCEL_NUMBER', 'Number ' . $foundNumber['number'] . ' cancelled', 'dashboard');
            sendResponse(['success' => true]);
        } else {
            sendError('Failed to update');
        }
        break;
        
    case 'completeNumber':
        requireAuth();
        
        $numberId = $_POST['id'] ?? '';
        
        $numbers = loadJson('numbers.json');
        $foundNumber = null;
        
        foreach ($numbers['active'] as $key => $num) {
            if ($num['id'] === $numberId) {
                // Check ownership
                if (!$isAdmin && $num['userId'] !== $currentUserId) {
                    sendError('Unauthorized', 403);
                }
                
                $foundNumber = $num;
                $foundNumber['status'] = 'completed';
                unset($numbers['active'][$key]);
                break;
            }
        }
        
        if (!$foundNumber) {
            sendError('Number not found');
        }
        
        $numbers['active'] = array_values($numbers['active']);
        array_unshift($numbers['history'], $foundNumber);
        
        // Keep only last 500 history items
        if (count($numbers['history']) > 500) {
            $numbers['history'] = array_slice($numbers['history'], 0, 500);
        }
        
        if (saveJson('numbers.json', $numbers)) {
            logAction($currentUserId, $_SESSION['username'], 'COMPLETE_NUMBER', 'Number ' . $foundNumber['number'] . ' completed');
            logActivity($currentUserId, $_SESSION['username'], 'COMPLETE_NUMBER', 'Number ' . $foundNumber['number'] . ' completed', 'dashboard');
            sendResponse(['success' => true]);
        } else {
            sendError('Failed to update');
        }
        break;
        
    // ========== LOGS (Admin only) ==========
    case 'getLogs':
        requireAdmin();
        $logs = loadJson('logs.json');
        sendResponse(['success' => true, 'logs' => $logs['logs'] ?? []]);
        break;
        
    // ========== ACTIVITIES (Admin only) ==========
    case 'getActivities':
        requireAdmin();
        $activity = loadJson('activity.json');
        $activities = $activity['activities'] ?? [];
        sendResponse(['success' => true, 'activities' => $activities]);
        break;
        
    default:
        sendError('Invalid action: ' . $action);
}

// Helper function to get default countries
function getDefaultCountries() {
    return [
        ['id' => '1', 'code' => 'PK', 'name' => 'Pakistan', 'smsHeroCode' => '66', 'flag' => '🇵🇰', 'active' => true],
        ['id' => '2', 'code' => 'US', 'name' => 'USA', 'smsHeroCode' => '12', 'flag' => '🇺🇸', 'active' => true],
        ['id' => '3', 'code' => 'UK', 'name' => 'United Kingdom', 'smsHeroCode' => '14', 'flag' => '🇬🇧', 'active' => true],
        ['id' => '4', 'code' => 'CA', 'name' => 'Canada', 'smsHeroCode' => '36', 'flag' => '🇨🇦', 'active' => true],
        ['id' => '5', 'code' => 'AU', 'name' => 'Australia', 'smsHeroCode' => '54', 'flag' => '🇦🇺', 'active' => true],
        ['id' => '6', 'code' => 'DE', 'name' => 'Germany', 'smsHeroCode' => '43', 'flag' => '🇩🇪', 'active' => true],
        ['id' => '7', 'code' => 'FR', 'name' => 'France', 'smsHeroCode' => '78', 'flag' => '🇫🇷', 'active' => true],
        ['id' => '8', 'code' => 'RU', 'name' => 'Russia', 'smsHeroCode' => '0', 'flag' => '🇷🇺', 'active' => true],
        ['id' => '9', 'code' => 'CN', 'name' => 'China', 'smsHeroCode' => '3', 'flag' => '🇨🇳', 'active' => true],
        ['id' => '10', 'code' => 'IN', 'name' => 'India', 'smsHeroCode' => '22', 'flag' => '🇮🇳', 'active' => true],
        ['id' => '11', 'code' => 'JP', 'name' => 'Japan', 'smsHeroCode' => '50', 'flag' => '🇯🇵', 'active' => true],
        ['id' => '12', 'code' => 'KR', 'name' => 'South Korea', 'smsHeroCode' => '61', 'flag' => '🇰🇷', 'active' => true],
        ['id' => '13', 'code' => 'BR', 'name' => 'Brazil', 'smsHeroCode' => '73', 'flag' => '🇧🇷', 'active' => true],
        ['id' => '14', 'code' => 'MX', 'name' => 'Mexico', 'smsHeroCode' => '54', 'flag' => '🇲🇽', 'active' => true],
        ['id' => '15', 'code' => 'TR', 'name' => 'Turkey', 'smsHeroCode' => '62', 'flag' => '🇹🇷', 'active' => true],
        ['id' => '16', 'code' => 'EG', 'name' => 'Egypt', 'smsHeroCode' => '21', 'flag' => '🇪🇬', 'active' => true],
        ['id' => '17', 'code' => 'ID', 'name' => 'Indonesia', 'smsHeroCode' => '6', 'flag' => '🇮🇩', 'active' => true],
        ['id' => '18', 'code' => 'TH', 'name' => 'Thailand', 'smsHeroCode' => '52', 'flag' => '🇹🇭', 'active' => true],
        ['id' => '19', 'code' => 'VN', 'name' => 'Vietnam', 'smsHeroCode' => '10', 'flag' => '🇻🇳', 'active' => true],
        ['id' => '20', 'code' => 'PH', 'name' => 'Philippines', 'smsHeroCode' => '4', 'flag' => '🇵🇭', 'active' => true],
        ['id' => '21', 'code' => 'BD', 'name' => 'Bangladesh', 'smsHeroCode' => '60', 'flag' => '🇧🇩', 'active' => true],
        ['id' => '22', 'code' => 'CO', 'name' => 'Colombia', 'smsHeroCode' => '33', 'flag' => '🇨🇴', 'active' => true],
    ];
}
?>
