<?php
session_start();

// Security headers
header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Content-Security-Policy: default-src \'self\'; script-src \'self\' \'unsafe-inline\' \'unsafe-eval\'; style-src \'self\' \'unsafe-inline\' https://fonts.googleapis.com; font-src \'self\' https://fonts.gstatic.com; img-src \'self\' data: https:; connect-src \'self\'; frame-src https://www.youtube.com;');

// Error reporting (disable in production)
error_reporting(0);
ini_set('display_errors', 0);

// Data directory - use absolute path
define('DATA_DIR', dirname(__DIR__) . '/data/');

// Rate limiting
function checkRateLimit($key, $maxAttempts = 5, $window = 300) {
    $rateFile = DATA_DIR . 'rate_limits.json';
    $rates = [];
    
    if (file_exists($rateFile)) {
        $content = file_get_contents($rateFile);
        $rates = json_decode($content, true) ?: [];
    }
    
    $now = time();
    $userKey = $_SERVER['REMOTE_ADDR'] . '_' . $key;
    
    // Clean old entries
    foreach ($rates as $k => $v) {
        if ($v['reset'] < $now) {
            unset($rates[$k]);
        }
    }
    
    if (!isset($rates[$userKey])) {
        $rates[$userKey] = ['count' => 0, 'reset' => $now + $window];
    }
    
    if ($rates[$userKey]['count'] >= $maxAttempts) {
        return false;
    }
    
    $rates[$userKey]['count']++;
    
    file_put_contents($rateFile, json_encode($rates, JSON_PRETTY_PRINT));
    return true;
}

// Helper functions
function loadJson($filename) {
    $filepath = DATA_DIR . $filename;
    if (!file_exists($filepath)) {
        return null;
    }
    $content = file_get_contents($filepath);
    if ($content === false) {
        return null;
    }
    $data = json_decode($content, true);
    return $data;
}

function saveJson($filename, $data) {
    $filepath = DATA_DIR . $filename;
    $dir = dirname($filepath);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    
    // Create backup before saving
    if (file_exists($filepath)) {
        $backupPath = $filepath . '.backup.' . date('Y-m-d-H-i-s');
        copy($filepath, $backupPath);
        
        // Keep only last 10 backups
        $backups = glob($filepath . '.backup.*');
        if (count($backups) > 10) {
            usort($backups, function($a, $b) {
                return filemtime($a) - filemtime($b);
            });
            array_splice($backups, 0, count($backups) - 10);
            foreach ($backups as $backup) {
                unlink($backup);
            }
        }
    }
    
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return false;
    }
    
    // Write to temp file first, then rename for atomic operation
    $tempFile = $filepath . '.tmp';
    if (file_put_contents($tempFile, $json) === false) {
        return false;
    }
    
    return rename($tempFile, $filepath);
}

function generateId() {
    return bin2hex(random_bytes(16));
}

function hashPassword($password) {
    // Use BCRYPT for better compatibility
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

function sanitizeInput($input) {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

function sendResponse($data) {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function sendError($message, $code = 400) {
    http_response_code($code);
    sendResponse(['success' => false, 'error' => $message]);
}

function logAction($userId, $username, $action, $details) {
    $logs = loadJson('logs.json');
    if (!$logs) {
        $logs = ['logs' => []];
    }
    
    $logs['logs'][] = [
        'id' => generateId(),
        'userId' => sanitizeInput($userId),
        'username' => sanitizeInput($username),
        'action' => sanitizeInput($action),
        'details' => sanitizeInput($details),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'userAgent' => sanitizeInput($_SERVER['HTTP_USER_AGENT'] ?? 'unknown'),
        'time' => date('Y-m-d H:i:s')
    ];
    
    // Keep only last 1000 logs
    if (count($logs['logs']) > 1000) {
        $logs['logs'] = array_slice($logs['logs'], -1000);
    }
    
    saveJson('logs.json', $logs);
}

function logActivity($userId, $username, $activityType, $details, $page = '') {
    $activity = loadJson('activity.json');
    if (!$activity) {
        $activity = ['activities' => []];
    }
    
    $activity['activities'][] = [
        'id' => generateId(),
        'userId' => sanitizeInput($userId),
        'username' => sanitizeInput($username),
        'activityType' => sanitizeInput($activityType),
        'details' => sanitizeInput($details),
        'page' => sanitizeInput($page),
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'userAgent' => sanitizeInput($_SERVER['HTTP_USER_AGENT'] ?? 'unknown'),
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    // Keep only last 1000 activities
    if (count($activity['activities']) > 1000) {
        $activity['activities'] = array_slice($activity['activities'], -1000);
    }
    
    saveJson('activity.json', $activity);
}

function requireAuth() {
    if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
        sendError('Unauthorized. Please login.', 401);
    }
}

function requireAdmin() {
    requireAuth();
    if (!isset($_SESSION['type']) || $_SESSION['type'] !== 'admin') {
        sendError('Admin access required', 403);
    }
}

function getCurrentUser() {
    if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in'] || $_SESSION['type'] !== 'user') {
        return null;
    }
    
    $users = loadJson('users.json');
    if (!$users) return null;
    
    foreach ($users['users'] as $user) {
        if ($user['id'] === $_SESSION['user_id']) {
            return $user;
        }
    }
    return null;
}

// Validate CSRF token (optional implementation)
function validateCsrfToken($token) {
    if (!isset($_SESSION['csrf_token']) || $token !== $_SESSION['csrf_token']) {
        sendError('Invalid CSRF token', 403);
    }
}

function generateCsrfToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Initialize data files if they don't exist
function initDataFiles() {
    // Admin password: ApexAdmin2025!
    // Pre-generated hash for ApexAdmin2025!
    $adminPasswordHash = '$2b$12$Da69/baXIbqx4cIj8Ajmv.uBsuLcr5WplPDXCbZiTl9jvxuNbbCxm';
    
    $files = [
        'config.json' => [
            'admin' => [
                'username' => 'Admin',
                'password' => $adminPasswordHash
            ],
            'api' => [
                'key' => '',
                'url' => 'https://hero-sms.com/stubs/handler_api.php'
            ],
            'settings' => [
                'numberExpiry' => 900,
                'whatsappNumber' => '',
                'tutorialVideo' => '',
                'supportMessage' => 'Hello! I need help with Apex SMS service.',
                'adminWhatsApp' => ''
            ]
        ],
        'users.json' => ['users' => []],
        'numbers.json' => ['active' => [], 'history' => []],
        'topups.json' => ['requests' => []],
        'services.json' => ['services' => []],
        'countries.json' => ['countries' => []],
        'logs.json' => ['logs' => []],
        'activity.json' => ['activities' => []],
        'pending_operations.json' => ['pending' => []]
    ];
    
    foreach ($files as $filename => $defaultData) {
        $filepath = DATA_DIR . $filename;
        if (!file_exists($filepath)) {
            saveJson($filename, $defaultData);
        }
    }
}

// Initialize on first load
initDataFiles();
?>
