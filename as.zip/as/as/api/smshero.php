<?php
require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    sendError('Unauthorized', 401);
}

// Load config to get API key
$config = loadJson('config.json');
if (!$config || empty($config['api']['key'])) {
    sendError('API key not configured. Please contact admin.', 500);
}

$apiKey = $config['api']['key'];
$apiUrl = $config['api']['url'] ?? 'https://hero-sms.com/stubs/handler_api.php';

$action = $_GET['action'] ?? $_POST['action'] ?? '';

function callSmsHero($params) {
    global $apiUrl, $apiKey;
    
    $url = $apiUrl . '?' . http_build_query(array_merge($params, ['api_key' => $apiKey]));
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    
    $response = curl_exec($ch);
    $error = curl_error($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($error) {
        return ['error' => 'Connection error: ' . $error];
    }
    
    if ($httpCode !== 200) {
        return ['error' => 'HTTP error: ' . $httpCode];
    }
    
    // Parse SMS Hero response
    $response = trim($response);
    
    // Check for errors
    if (strpos($response, 'ERROR') === 0 || strpos($response, 'BAD') === 0) {
        return ['error' => $response];
    }
    
    // Parse ACCESS_NUMBER response: ACCESS_NUMBER:activation_id:number
    if (strpos($response, 'ACCESS_NUMBER:') === 0) {
        $parts = explode(':', $response);
        if (count($parts) >= 3) {
            return [
                'success' => true,
                'activationId' => $parts[1],
                'number' => $parts[2]
            ];
        }
    }
    
    // Parse ACCESS_BALANCE response: ACCESS_BALANCE:amount
    if (strpos($response, 'ACCESS_BALANCE:') === 0) {
        $parts = explode(':', $response);
        if (count($parts) >= 2) {
            return [
                'success' => true,
                'balance' => $parts[1]
            ];
        }
    }
    
    // Parse STATUS responses
    if (strpos($response, 'STATUS_OK:') === 0) {
        $parts = explode(':', $response);
        return [
            'success' => true,
            'status' => 'OK',
            'code' => $parts[1] ?? ''
        ];
    }
    
    if (strpos($response, 'STATUS_WAIT_CODE') === 0) {
        return [
            'success' => true,
            'status' => 'WAIT_CODE'
        ];
    }
    
    if (strpos($response, 'STATUS_CANCEL') === 0) {
        return [
            'success' => true,
            'status' => 'CANCEL'
        ];
    }
    
    if (strpos($response, 'STATUS_FINISH') === 0) {
        return [
            'success' => true,
            'status' => 'FINISH'
        ];
    }
    
    // Return raw response for debugging
    return ['success' => true, 'raw' => $response];
}

// Process pending operations (cancels, refunds, auto-cancels)
function processPendingOperations() {
    $pending = loadJson('pending_operations.json');
    if (!$pending) {
        $pending = ['pending' => []];
    }
    
    $now = time();
    $remaining = [];
    
    foreach ($pending['pending'] as $operation) {
        $executeTime = strtotime($operation['executeAt']);
        
        if ($now >= $executeTime) {
            // Time to execute the operation
            if ($operation['type'] === 'cancel' || $operation['type'] === 'refund_cancel') {
                // Cancel from SMS-HERO
                $result = callSmsHero([
                    'action' => 'setStatus',
                    'status' => '8',
                    'id' => $operation['activationId']
                ]);
                
                // If refund is requested and no code was received, refund the user
                if ($operation['type'] === 'refund_cancel' && isset($operation['userId']) && isset($operation['price'])) {
                    $users = loadJson('users.json');
                    foreach ($users['users'] as &$user) {
                        if ($user['id'] === $operation['userId']) {
                            $user['balance'] = ($user['balance'] ?? 0) + $operation['price'];
                            break;
                        }
                    }
                    saveJson('users.json', $users);
                    logAction($operation['userId'], $operation['username'] ?? 'unknown', 'REFUND_PROCESSED', 'Refunded PKR ' . $operation['price'] . ' for cancelled number');
                }
                
                // Log the cancel
                logAction($operation['userId'] ?? 'system', $operation['username'] ?? 'system', 'AUTO_CANCEL', 'Cancelled activation: ' . $operation['activationId'] . ' from SMS-HERO');
            } elseif ($operation['type'] === 'timeout_cancel') {
                // Auto-cancel expired numbers
                $result = callSmsHero([
                    'action' => 'setStatus',
                    'status' => '8',
                    'id' => $operation['activationId']
                ]);
                
                logAction($operation['userId'] ?? 'system', $operation['username'] ?? 'system', 'TIMEOUT_CANCEL', 'Auto-cancelled expired number: ' . $operation['activationId']);
            }
        } else {
            $remaining[] = $operation;
        }
    }
    
    $pending['pending'] = $remaining;
    saveJson('pending_operations.json', $pending);
}

// Process pending operations on each request
processPendingOperations();

// Country code mapping - EXTENDED with more countries
$countryMap = [
    // Common countries
    'CO' => '33',  // Colombia
    'TH' => '52',  // Thailand
    'ID' => '6',   // Indonesia
    'BR' => '73',  // Brazil
    'IN' => '22',  // India
    'PK' => '66',  // Pakistan
    'BD' => '60',  // Bangladesh
    'US' => '12',  // USA
    'UK' => '14',  // UK
    'CA' => '36',  // Canada
    'AU' => '54',  // Australia
    'DE' => '43',  // Germany
    'FR' => '78',  // France
    'RU' => '0',   // Russia
    'CN' => '3',   // China
    'JP' => '50',  // Japan
    'KR' => '61',  // South Korea
    'MX' => '54',  // Mexico
    'TR' => '62',  // Turkey
    'EG' => '21',  // Egypt
    'VN' => '10',  // Vietnam
    'PH' => '4',   // Philippines
    'MY' => '7',   // Malaysia
    'SG' => '9',   // Singapore
    'TW' => '1',   // Taiwan
    'HK' => '2',   // Hong Kong
    'NL' => '48',  // Netherlands
    'IT' => '86',  // Italy
    'ES' => '56',  // Spain
    'PL' => '15',  // Poland
    'UA' => '93',  // Ukraine
    'KZ' => '2',   // Kazakhstan
    'UZ' => '2',   // Uzbekistan
    'AZ' => '2',   // Azerbaijan
    'GE' => '2',   // Georgia
    'AM' => '2',   // Armenia
    'BY' => '2',   // Belarus
    'MD' => '2',   // Moldova
    'LT' => '44',  // Lithuania
    'LV' => '49',  // Latvia
    'EE' => '39',  // Estonia
    'FI' => '37',  // Finland
    'SE' => '46',  // Sweden
    'NO' => '57',  // Norway
    'DK' => '51',  // Denmark
    'CH' => '45',  // Switzerland
    'AT' => '40',  // Austria
    'BE' => '41',  // Belgium
    'CZ' => '63',  // Czech Republic
    'SK' => '41',  // Slovakia
    'HU' => '67',  // Hungary
    'RO' => '32',  // Romania
    'BG' => '70',  // Bulgaria
    'HR' => '68',  // Croatia
    'SI' => '68',  // Slovenia
    'RS' => '68',  // Serbia
    'BA' => '68',  // Bosnia
    'ME' => '68',  // Montenegro
    'MK' => '68',  // Macedonia
    'AL' => '68',  // Albania
    'GR' => '47',  // Greece
    'PT' => '74',  // Portugal
    'IE' => '42',  // Ireland
    'IS' => '42',  // Iceland
    'MT' => '42',  // Malta
    'CY' => '42',  // Cyprus
    'LU' => '42',  // Luxembourg
    'MC' => '42',  // Monaco
    'LI' => '42',  // Liechtenstein
    'AD' => '42',  // Andorra
    'SM' => '42',  // San Marino
    'VA' => '42',  // Vatican
    'ZA' => '24',  // South Africa
    'NG' => '25',  // Nigeria
    'KE' => '26',  // Kenya
    'GH' => '27',  // Ghana
    'UG' => '28',  // Uganda
    'TZ' => '29',  // Tanzania
    'ZW' => '30',  // Zimbabwe
    'ZM' => '31',  // Zambia
    'MW' => '32',  // Malawi
    'MZ' => '33',  // Mozambique
    'MG' => '34',  // Madagascar
    'MU' => '35',  // Mauritius
    'SC' => '36',  // Seychelles
    'KM' => '37',  // Comoros
    'RE' => '38',  // Reunion
    'YT' => '39',  // Mayotte
    'AE' => '75',  // UAE
    'SA' => '76',  // Saudi Arabia
    'QA' => '77',  // Qatar
    'KW' => '78',  // Kuwait
    'BH' => '79',  // Bahrain
    'OM' => '80',  // Oman
    'JO' => '81',  // Jordan
    'LB' => '82',  // Lebanon
    'SY' => '83',  // Syria
    'IQ' => '84',  // Iraq
    'IR' => '85',  // Iran
    'YE' => '86',  // Yemen
    'AF' => '87',  // Afghanistan
    'PK' => '66',  // Pakistan
    'IN' => '22',  // India
    'NP' => '89',  // Nepal
    'BT' => '90',  // Bhutan
    'BD' => '60',  // Bangladesh
    'LK' => '91',  // Sri Lanka
    'MV' => '92',  // Maldives
    'MM' => '93',  // Myanmar
    'KH' => '94',  // Cambodia
    'LA' => '95',  // Laos
    'BN' => '96',  // Brunei
    'TL' => '97',  // Timor-Leste
    'PG' => '98',  // Papua New Guinea
    'FJ' => '99',  // Fiji
    'SB' => '100', // Solomon Islands
    'VU' => '101', // Vanuatu
    'NC' => '102', // New Caledonia
    'PF' => '103', // French Polynesia
    'GU' => '104', // Guam
    'AS' => '105', // American Samoa
    'WS' => '106', // Samoa
    'TO' => '107', // Tonga
    'KI' => '108', // Kiribati
    'TV' => '109', // Tuvalu
    'NR' => '110', // Nauru
    'PW' => '111', // Palau
    'MH' => '112', // Marshall Islands
    'FM' => '113', // Micronesia
    'CK' => '114', // Cook Islands
    'NU' => '115', // Niue
    'TK' => '116', // Tokelau
    'WF' => '117', // Wallis and Futuna
    'PN' => '118', // Pitcairn
    'CL' => '119', // Chile
    'AR' => '120', // Argentina
    'UY' => '121', // Uruguay
    'PY' => '122', // Paraguay
    'BO' => '123', // Bolivia
    'PE' => '124', // Peru
    'EC' => '125', // Ecuador
    'GY' => '126', // Guyana
    'SR' => '127', // Suriname
    'GF' => '128', // French Guiana
    'VE' => '129', // Venezuela
    'PA' => '130', // Panama
    'CR' => '131', // Costa Rica
    'NI' => '132', // Nicaragua
    'HN' => '133', // Honduras
    'SV' => '134', // El Salvador
    'GT' => '135', // Guatemala
    'BZ' => '136', // Belize
    'JM' => '137', // Jamaica
    'HT' => '138', // Haiti
    'DO' => '139', // Dominican Republic
    'CU' => '140', // Cuba
    'PR' => '141', // Puerto Rico
    'TT' => '142', // Trinidad and Tobago
    'BB' => '143', // Barbados
    'GD' => '144', // Grenada
    'LC' => '145', // Saint Lucia
    'VC' => '146', // Saint Vincent
    'AG' => '147', // Antigua and Barbuda
    'DM' => '148', // Dominica
    'KN' => '149', // Saint Kitts and Nevis
    'BS' => '150', // Bahamas
    'AI' => '151', // Anguilla
    'VG' => '152', // British Virgin Islands
    'KY' => '153', // Cayman Islands
    'TC' => '154', // Turks and Caicos
    'MS' => '155', // Montserrat
    'GL' => '156', // Greenland
    'FO' => '157', // Faroe Islands
    'AX' => '158', // Aland Islands
    'SJ' => '159', // Svalbard
    'BV' => '160', // Bouvet Island
    'HM' => '161', // Heard Island
    'GS' => '162', // South Georgia
    'IO' => '163', // British Indian Ocean
    'CX' => '164', // Christmas Island
    'CC' => '165', // Cocos Islands
    'NF' => '166', // Norfolk Island
    'HM' => '167', // Heard and McDonald
    'TF' => '168', // French Southern Territories
    'AQ' => '169', // Antarctica
    'UM' => '170', // US Minor Outlying Islands
    'NZ' => '171', // New Zealand
    'IL' => '172', // Israel
    'PS' => '173', // Palestine
    'MO' => '174', // Macau
    'GI' => '175', // Gibraltar
    'JE' => '176', // Jersey
    'GG' => '177', // Guernsey
    'IM' => '178', // Isle of Man
    'AW' => '179', // Aruba
    'CW' => '180', // Curacao
    'SX' => '181', // Sint Maarten
    'BQ' => '182', // Bonaire
    'BL' => '183', // Saint Barthelemy
    'MF' => '184', // Saint Martin
    'PM' => '185', // Saint Pierre
    'WF' => '186', // Wallis and Futuna
    'CK' => '187', // Cook Islands
    'NU' => '188', // Niue
    'TK' => '189', // Tokelau
    'AS' => '190', // American Samoa
    'GU' => '191', // Guam
    'MP' => '192', // Northern Mariana Islands
    'VI' => '193', // US Virgin Islands
    'PR' => '194', // Puerto Rico
    'AS' => '195', // American Samoa
];

// Service mapping - comprehensive list
$serviceMap = [
    'discord' => 'ds',
    'instagram' => 'ig',
    'whatsapp' => 'wa',
    'telegram' => 'tg',
    'facebook' => 'fb',
    'google' => 'go',
    'twitter' => 'tw',
    'tiktok' => 'tk',
    'snapchat' => 'sc',
    'amazon' => 'am',
    'netflix' => 'nf',
    'spotify' => 'sp',
    'uber' => 'ub',
    'paypal' => 'pp',
    'apple' => 'al',
    'microsoft' => 'mm',
    'linkedin' => 'ln',
    'pinterest' => 'pi',
    'reddit' => 're',
    'twitch' => 'tc',
    'steam' => 'st',
    'epicgames' => 'ep',
    'roblox' => 'rb',
    'youtube' => 'yo',
    'gmail' => 'gm',
    'yahoo' => 'yh',
    'outlook' => 'ot',
    'protonmail' => 'pm',
    'icloud' => 'ic',
    'vk' => 'vk',
    'ok' => 'ok',
    'wechat' => 'wc',
    'line' => 'li',
    'viber' => 'vi',
    'signal' => 'sg',
    'zoom' => 'zm',
    'teams' => 'tm',
    'slack' => 'sl',
    'skype' => 'sk',
    'tinder' => 'ti',
    'bumble' => 'bu',
    'hinge' => 'hi',
    'match' => 'ma',
    'ebay' => 'eb',
    'aliexpress' => 'ae',
    'shopify' => 'sh',
    'etsy' => 'et',
    'walmart' => 'wm',
    'target' => 'ta',
    'bestbuy' => 'bb',
    'hulu' => 'hu',
    'disney' => 'di',
    'hbo' => 'hb',
    'prime' => 'pr',
    'applemusic' => 'ap',
    'soundcloud' => 'so',
    'deezer' => 'dz',
    'tidal' => 'td',
    'pandora' => 'pa',
    'iheartradio' => 'ir',
    'audible' => 'au',
    'kindle' => 'ki',
    'goodreads' => 'gr',
    'strava' => 'sr',
    'nike' => 'ni',
    'adidas' => 'ad',
    'underarmour' => 'ua',
    'myfitnesspal' => 'mf',
    'fitbit' => 'fi',
    'garmin' => 'ga',
    'peloton' => 'pe',
    'classpass' => 'cp',
    'doordash' => 'dd',
    'grubhub' => 'gh',
    'ubereats' => 'ue',
    'postmates' => 'po',
    'instacart' => 'in',
    'shipt' => 'si',
    'gopuff' => 'gp',
    'lyft' => 'ly',
    'bird' => 'bi',
    'lime' => 'lm',
    'spin' => 'spn',
    'airbnb' => 'ab',
    'booking' => 'bk',
    'expedia' => 'ex',
    'hotels' => 'ho',
    'kayak' => 'ka',
    'priceline' => 'pl',
    'trivago' => 'tr',
    'tripadvisor' => 'tp',
    'yelp' => 'ye',
    'foursquare' => 'fs',
    'zillow' => 'zi',
    'realtor' => 'rl',
    'trulia' => 'tu',
    'apartments' => 'apts',
    'redfin' => 'rf',
    'opendoor' => 'od',
    'offerpad' => 'of',
    'carvana' => 'cv',
    'carmax' => 'cm',
    'autotrader' => 'at',
    'cars' => 'cars',
    'truecar' => 'tcar',
    'kbb' => 'kb',
    'edmunds' => 'ed',
    'cargurus' => 'cg',
    'bankofamerica' => 'boa',
    'chase' => 'ch',
    'wellsfargo' => 'wf',
    'citi' => 'ct',
    'capitalone' => 'co',
    'discover' => 'dc',
    'amex' => 'ax',
    'venmo' => 've',
    'cashapp' => 'ca',
    'zelle' => 'ze',
    'westernunion' => 'wu',
    'moneygram' => 'mg',
    'remitly' => 're',
    'wise' => 'wi',
    'revolut' => 'rv',
    'n26' => 'n2',
    'monzo' => 'mo',
    'starling' => 'st',
    'chime' => 'ci',
    'varo' => 'va',
    'sofi' => 'so',
    'ally' => 'al',
    'marcus' => 'ma',
    'betterment' => 'be',
    'wealthfront' => 'we',
    'robinhood' => 'ro',
    'webull' => 'wb',
    'etoro' => 'et',
    'coinbase' => 'cb',
    'binance' => 'bi',
    'kraken' => 'kr',
    'gemini' => 'ge',
    'blockfi' => 'bl',
    'celsius' => 'ce',
    'nexo' => 'ne',
    'crypto' => 'cr',
    'kucoin' => 'ku',
    'ftx' => 'ft',
    'huobi' => 'hb',
    'okx' => 'okx',
    'bybit' => 'by',
    'phemex' => 'ph',
    'deribit' => 'de',
    'bitmex' => 'bm',
    'bitfinex' => 'bf',
    'bitstamp' => 'bs',
    'bittrex' => 'bt',
    'poloniex' => 'po',
    'gate' => 'ga',
    'mexc' => 'me',
    'lbank' => 'lb'
];

switch ($action) {
    case 'balance':
        $result = callSmsHero(['action' => 'getBalance']);
        sendResponse($result);
        break;
        
    case 'getNumber':
        $service = $_POST['service'] ?? 'ds';
        $country = $_POST['country'] ?? 'CO';
        
        // Apply country code mapping
        if (isset($countryMap[$country])) {
            $country = $countryMap[$country];
        }
        
        // Apply service mapping
        $serviceLower = strtolower($service);
        if (isset($serviceMap[$serviceLower])) {
            $service = $serviceMap[$serviceLower];
        }
        
        $result = callSmsHero([
            'action' => 'getNumber',
            'service' => $service,
            'country' => $country
        ]);
        
        sendResponse($result);
        break;
        
    case 'getStatus':
        $activationId = $_GET['id'] ?? '';
        if (empty($activationId)) {
            sendError('Activation ID required');
        }
        
        $result = callSmsHero([
            'action' => 'getStatus',
            'id' => $activationId
        ]);
        
        sendResponse($result);
        break;
        
    case 'cancel':
        $activationId = $_POST['id'] ?? '';
        $numberId = $_POST['numberId'] ?? '';
        $refund = $_POST['refund'] ?? 'false';
        $price = floatval($_POST['price'] ?? 0);
        
        if (empty($activationId)) {
            sendError('Activation ID required');
        }
        
        // IMMEDIATELY cancel from SMS-HERO (don't wait 135 seconds)
        $cancelResult = callSmsHero([
            'action' => 'setStatus',
            'status' => '8',
            'id' => $activationId
        ]);
        
        // If refund is requested and no code was received, schedule refund
        if ($refund === 'true' && $price > 0) {
            $users = loadJson('users.json');
            foreach ($users['users'] as &$user) {
                if ($user['id'] === ($_SESSION['user_id'] ?? '')) {
                    $user['balance'] = ($user['balance'] ?? 0) + $price;
                    break;
                }
            }
            saveJson('users.json', $users);
            logAction($_SESSION['user_id'] ?? 'unknown', $_SESSION['username'] ?? 'unknown', 'REFUND', 'Refunded PKR ' . $price . ' for cancelled number');
        }
        
        logAction($_SESSION['user_id'] ?? 'unknown', $_SESSION['username'] ?? 'unknown', 'CANCEL', 'Cancelled activation: ' . $activationId);
        
        sendResponse([
            'success' => true,
            'message' => 'Number cancelled successfully',
            'cancelResult' => $cancelResult,
            'refunded' => $refund === 'true'
        ]);
        break;
        
    case 'scheduleCancel':
        // Schedule a cancel after 135 seconds (for replace operations)
        $activationId = $_POST['id'] ?? '';
        
        if (empty($activationId)) {
            sendError('Activation ID required');
        }
        
        $pending = loadJson('pending_operations.json');
        if (!$pending) {
            $pending = ['pending' => []];
        }
        
        $pending['pending'][] = [
            'id' => generateId(),
            'type' => 'cancel',
            'activationId' => sanitizeInput($activationId),
            'userId' => $_SESSION['user_id'] ?? 'unknown',
            'username' => $_SESSION['username'] ?? 'unknown',
            'scheduledAt' => date('Y-m-d H:i:s'),
            'executeAt' => date('Y-m-d H:i:s', time() + 135)
        ];
        
        saveJson('pending_operations.json', $pending);
        
        logAction($_SESSION['user_id'] ?? 'unknown', $_SESSION['username'] ?? 'unknown', 'CANCEL_SCHEDULED', 'Cancel scheduled for activation: ' . $activationId);
        
        sendResponse([
            'success' => true,
            'message' => 'Cancel scheduled. Will execute after 135 seconds.',
            'scheduled' => true
        ]);
        break;
        
    case 'getPrices':
        $country = $_GET['country'] ?? '52';
        $result = callSmsHero([
            'action' => 'getPrices',
            'country' => $country
        ]);
        sendResponse($result);
        break;
        
    default:
        sendError('Invalid action: ' . $action);
}
?>
