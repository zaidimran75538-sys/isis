# Apex SMS - SMS Verification Platform

A professional SMS verification service platform that provides virtual phone numbers for verification codes from various services.

## Features

### User Features
- **Instant Number Delivery** - Get virtual numbers within seconds
- **100+ Services Supported** - Discord, Instagram, WhatsApp, Telegram, Facebook, Google, and more
- **50+ Countries Available** - USA, UK, Canada, Germany, Pakistan, and many more
- **135-Second Cancel Window** - Cancel and get full refund if no code received within 135 seconds
- **15-Minute Expiry** - Numbers valid for 15 minutes with auto-cancel from SMS-HERO
- **Refund Policy** - Full refund when canceling before receiving OTP
- **Topup System** - Easy balance topup with WhatsApp notification
- **User Dashboard** - Track active numbers, history, and balance

### Admin Features
- **User Management** - Create, edit, delete users with filtering and sorting
- **Countries Management** - Add/edit countries with SMS-HERO code mapping
- **Services Management** - Add services with custom pricing per country
- **Topup Management** - Approve/reject topup requests
- **Activity Logs** - Track all user activities with filtering
- **System Logs** - Monitor all system actions
- **Settings** - Configure API keys, WhatsApp numbers, and admin password

## File Structure

```
/
├── api/                    # PHP API endpoints
│   ├── auth.php           # Authentication (login, signup, logout)
│   ├── config.php         # Configuration and helper functions
│   ├── manage.php         # Admin/user management APIs
│   └── smshero.php        # SMS-HERO API integration
├── css/
│   └── style.css          # Main stylesheet
├── data/                  # JSON data storage (protected by .htaccess)
├── .htaccess              # Security configuration
├── index.html             # Landing page
├── login.html             # User login/signup
├── admin-login.html       # Admin login
├── dashboard.html         # User dashboard
└── admin.html             # Admin panel
```

## Installation

1. Upload all files to your web server
2. Ensure the `data/` directory is writable (chmod 755)
3. Access `admin-login.html` and login with:
   - Username: `admin`
   - Password: `admin123`
4. Go to Settings and configure your SMS-HERO API key
5. Add countries and services in the admin panel

## Security Features

- **Rate Limiting** - Prevents brute force attacks on login
- **CSRF Protection** - Built-in CSRF token validation
- **Password Hashing** - BCRYPT with cost 12
- **Input Sanitization** - All inputs are sanitized
- **File Protection** - Sensitive files blocked via .htaccess
- **Data Backup** - Automatic JSON backups before writes
- **Security Headers** - X-Frame-Options, X-Content-Type-Options, etc.

## SMS-HERO Integration

The platform integrates with SMS-HERO API for virtual numbers:
- Automatic country code mapping
- Service code mapping
- Real-time status checking
- Immediate cancel on user request
- Auto-cancel on expiry

## Key Fixes & Improvements

### Fixed Issues:
1. **USA/UK Number Issue** - Fixed country code mapping for USA (12) and UK (14)
2. **135-Second Timer** - Fixed timer showing wrong values (was showing minutes instead of seconds)
3. **Cancel System** - Now cancels immediately from SMS-HERO with proper refund
4. **Auto-Cancel** - Numbers auto-cancel from SMS-HERO after 15 minutes
5. **Refund System** - Full refund when canceling before receiving OTP

### New Features:
1. **Countries Tab** - Separate country management in admin panel
2. **User Filtering** - Filter users by status, search by username/email/phone
3. **Activity Tracking** - Track all user activities with filters
4. **Topup Notifications** - WhatsApp integration for topup requests
5. **Professional UI** - Completely redesigned homepage and dashboard

## Default Admin Credentials

- **Username:** `admin`
- **Password:** `admin123`

**Important:** Change the default password immediately after first login!

## API Configuration

In Admin Panel > Settings, configure:
- SMS-HERO API Key
- API URL (default: https://hero-sms.com/stubs/handler_api.php)
- Admin WhatsApp Number (for topup notifications)
- Support WhatsApp Number
- Tutorial Video URL

## Data Files

The following JSON files are created in the `data/` directory:
- `config.json` - System configuration
- `users.json` - User accounts
- `numbers.json` - Active and history numbers
- `topups.json` - Topup requests
- `services.json` - Available services
- `countries.json` - Country mappings
- `logs.json` - System logs
- `activity.json` - User activities
- `pending_operations.json` - Scheduled operations
- `rate_limits.json` - Rate limiting data

## Support

For support, contact via WhatsApp or email.

## License

This is a proprietary software. All rights reserved.
